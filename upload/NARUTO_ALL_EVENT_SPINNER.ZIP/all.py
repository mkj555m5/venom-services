#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NARUTO  SPINNER — OB55 EDITION  (MULTI-EVENT)
Credit: KAWSAR | x64
Telegram: @kawsar449x

Supports TWO account-file formats:
  1. JSON array  →  [{"uid":..., "password":...}, ...]
  2. Block text  →  kawsar.py output (UID / GAME UID / NICKNAME / ...)
"""
import sys, os, subprocess, time, json, binascii, asyncio, re, importlib

# ─────────────────────────────────────────────
#  SAFE AUTO-INSTALL  (re-execs if it installs anything)
# ─────────────────────────────────────────────
def install_requirements():
    C_CYAN   = "\033[1;36m"
    C_YELLOW = "\033[1;33m"
    C_GREEN  = "\033[1;32m"
    C_RESET  = "\033[0m"

    print(f"{C_CYAN}[»] Checking requirements...{C_RESET}")

    required = [
        ('aiohttp',  'aiohttp'),
        ('Crypto',   'pycryptodome'),
        ('aiofiles', 'aiofiles'),
    ]

    missing = []
    for imp_name, pip_name in required:
        try:
            __import__(imp_name)
        except ImportError:
            missing.append(pip_name)

    if missing:
        for pip_name in missing:
            print(f"{C_YELLOW}[!] Installing {pip_name}...{C_RESET}")
            try:
                subprocess.check_call(
                    [sys.executable, '-m', 'pip', 'install', pip_name, '--quiet'],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
            except subprocess.CalledProcessError:
                print(f"{C_YELLOW}[!] pip failed for {pip_name} — trying with --user{C_RESET}")
                subprocess.check_call(
                    [sys.executable, '-m', 'pip', 'install', '--user', pip_name, '--quiet']
                )

        print(f"{C_GREEN}[✓] Packages installed — restarting script...{C_RESET}\n")
        importlib.invalidate_caches()
        os.execv(sys.executable, [sys.executable] + sys.argv)

    print(f"{C_GREEN}[✓] All requirements ready!{C_RESET}\n")

install_requirements()

# ── NOW safe to import ──
import aiofiles
import aiohttp
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from datetime import datetime
import gzip as _gzip

# ── COLORS ──
C_RED     = "\033[1;31m"
C_GREEN   = "\033[1;32m"
C_YELLOW  = "\033[1;33m"
C_CYAN    = "\033[1;36m"
C_WHITE   = "\033[1;37m"
C_GOLD    = "\033[1;33;40m"
C_PINK    = "\033[1;95m"
C_RESET   = "\033[0m"
C_BG_RED  = "\033[1;37;41m"
C_BLUE    = "\033[1;34m"
C_BG_GREEN   = "\033[1;37;42m"
C_BG_YELLOW  = "\033[1;37;43m"
C_BG_MAGENTA = "\033[1;37;45m"
C_BG_CYAN    = "\033[1;37;46m"
C_DIM        = "\033[2m"

# ─────────────────────────────────────────────
#  KAWSAR ASCII BANNER
# ─────────────────────────────────────────────
KAWSAR_BANNER = r"""
██╗░░██╗░█████╗░░██╗░░░░░░░██╗░██████╗░█████╗░██████╗░
██║░██╔╝██╔══██╗░██║░░██╗░░██║██╔════╝██╔══██╗██╔══██╗
█████═╝░███████║░╚██╗████╗██╔╝╚█████╗░███████║██████╔╝
██╔═██╗░██╔══██║░░████╔═████║░░╚═══██╗██╔══██║██╔══██╗
██║░╚██╗██║░░██║░░╚██╔╝░╚██╔╝░██████╔╝██║░░██║██║░░██║
╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝"""

def grad(text, a, b):
    out = ""
    n = max(len(text) - 1, 1)
    for i, ch in enumerate(text):
        t  = i / n
        r  = int(a[0] + (b[0]-a[0])*t)
        g  = int(a[1] + (b[1]-a[1])*t)
        bl = int(a[2] + (b[2]-a[2])*t)
        out += f"\033[38;2;{r};{g};{bl}m{ch}"
    return out + C_RESET

CREDIT_INFO = f"""
{grad(KAWSAR_BANNER, (0,200,255), (180,80,255))}

{C_PINK}╔═══════════════════════════════════════════════════════════╗{C_RESET}
{C_PINK}║{C_GOLD}     🐰 FREE FIRE  ·  NARUTO   MULTI-SPINNER  🐰      {C_PINK}║{C_RESET}
{C_PINK}╠═══════════════════════════════════════════════════════════╣{C_RESET}
{C_PINK}║{C_GREEN}  👑  Credit     : {C_WHITE}KAWSAR | x64{C_GREEN}                            {C_PINK}║{C_RESET}
{C_PINK}║{C_CYAN}  📱  Telegram   : {C_WHITE}@kawsar449x{C_CYAN}                             {C_PINK}║{C_RESET}
{C_PINK}║{C_YELLOW}  ⚡  Version    : {C_WHITE}OB55  ·  5 EVENTS  ·  Fast{C_YELLOW}              {C_PINK}║{C_RESET}
{C_PINK}╚═══════════════════════════════════════════════════════════╝{C_RESET}
"""

# ─────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────
AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV  = b'6oyZDr22E3ychjM%'

# ──► DEFAULT ACCOUNTS FILE  ◄────────────────────────────────
ACCOUNTS_FILE = "KAWSARxGEN/accounts-BD.json"

LOGIN_HOST   = "clientbp.ppmainecoonghj.com"
DEFAULT_URL  = f"https://{LOGIN_HOST}"
RELEASE_VER  = "OB55"
UNITY_VER    = "2018.4.12f1"

# ── GLOBAL OUTPUT FILES ──────────────────────────────────────
SUMMARY_FILE = "NARUTO_spins_summary.txt"
LOG_FILE     = "NARUTO_spins_log.txt"
OUTPUT_FILE  = "NARUTO_spins_raw.txt"

# ── EVENT DEFINITIONS ────────────────────────────────────────
EVENTS = {
    "naruto": {
        "name":     "NARUTO",
        "payload":  {1: 33, 2: 1, 3: 553, 4: 5, 13: 2},
        "prefix":   "NARUTO",
    },
    "skywin": {
        "name":     "NARUTO SKYWIN",
        "payload":  {1: 11, 2: 1, 3: 553, 4: 5, 13: 2},
        "prefix":   "SKYWIN",
    },
    "fist": {
        "name":     "NARUTO FIST",
        "payload":  {1: 29, 2: 1, 3: 553, 4: 3, 13: 2},
        "prefix":   "FIST",
    },
    "sasuke": {
        "name":     "SASUKE BUNDLE",
        "payload":  {1: 91, 2: 1, 3: 554, 4: 5, 13: 2},
        "prefix":   "SASUKE",
    },
}

# ── ITEM DATABASE (merged across all events) ──
ITEM_DB = {
    # ── NARUTO (event 1) ──
    710047022: ("NARUTO BUNDLE",         "VERY_RARE"),
    909047015: ("RASENGAN EMOTE",        "RARE"),
    907104746: ("HOKAGE ROCK GLOW WALL", "RARE"),
    904047008: ("HOKAGE GLOW WALL",      "NORMAL"),
    903047008: ("RASENGAN SKIN",         "NORMAL"),

    # ── NARUTO SKYWIN (event 2) ──
    911004701: ("NARUTO SKYWIN",         "VERY_RARE"),
    907104744: ("M4A1 - NARUTO THEME",   "RARE"),
    211047048: ("OBITO MASK",            "RARE"),

    # ── NARUTO FIST (event 3) ──
    907104745: ("FIST",                  "VERY_RARE"),

    # ── SASUKE BUNDLE (event 4) ──
    710047023: ("SASUKE BUNDLE",         "VERY_RARE"),
    907104743: ("KATANA",                "RARE"),
    907104742: ("KATANA",                "RARE"),
    907104748: ("GROZA",                 "RARE"),
}

def classify_item(item_id: int):
    if item_id in ITEM_DB:
        return ITEM_DB[item_id]
    return (f"UNKNOWN_{item_id}", "NORMAL")

# ─────────────────────────────────────────────
#  ACCOUNT FILE LOADER  (unchanged)
# ─────────────────────────────────────────────
def load_accounts(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        raw = f.read()

    # ── try JSON first ──
    try:
        data = json.loads(raw)
        if isinstance(data, list):
            records = data
        elif isinstance(data, dict) and 'accounts' in data:
            records = data['accounts']
        else:
            records = None

        if records is not None:
            normalized = []
            for r in records:
                if not isinstance(r, dict):
                    continue
                entry = dict(r)

                if 'uid' not in entry or not entry['uid']:
                    for alt in ('Account_uid', 'external_uid', 'Open_id'):
                        if r.get(alt):
                            entry['uid'] = str(r[alt])
                            break

                if 'password' not in entry or not entry['password']:
                    for alt in ('Password', 'PASSWORD', 'pass', 'Pass'):
                        if r.get(alt):
                            entry['password'] = r[alt]
                            break

                if 'access_token' not in entry and r.get('Access_token'):
                    entry['access_token'] = r['Access_token']
                if 'jwt' not in entry and r.get('Jwt_token'):
                    entry['jwt'] = r['Jwt_token']
                if 'region' not in entry and r.get('Region'):
                    entry['region'] = r['Region']

                normalized.append(entry)
            return normalized
    except Exception:
        pass

    # ── fall back to block-text parser ──
    accounts = []
    current = {}
    raw = re.sub(r'\033\[[0-9;]*m', '', raw)

    FIELD_MAP = {
        "UID":          "uid",
        "GAME UID":     "game_uid",
        "NICKNAME":     "nickname",
        "PASSWORD":     "password",
        "REGION":       "region",
        "ACCESS TOKEN": "access_token",
        "OPEN ID":      "open_id",
        "JWT":          "jwt",
        "ONLINE IP":    "online_ip_port",
        "ACCOUNT IP":   "account_ip_port",
    }

    for line in raw.splitlines():
        line = line.strip()

        if not line or set(line) <= set('─-—_ '):
            if current.get("uid"):
                accounts.append(current)
                current = {}
            continue

        m = re.match(r'^([A-Z][A-Z0-9 _]+?)\s*:\s*(.*)$', line)
        if not m:
            continue

        label = m.group(1).strip()
        value = m.group(2).strip()

        key = FIELD_MAP.get(label)
        if key:
            current[key] = value

    if current.get("uid"):
        accounts.append(current)

    if not accounts:
        raise ValueError("No accounts found — file is neither JSON nor kawsar block format")

    return accounts

# ── buffers & locks ──
LOG_BUFFER    = []
OUTPUT_BUFFER = []
LOG_LOCK      = asyncio.Lock()
OUTPUT_LOCK   = asyncio.Lock()
JSON_LOCK     = asyncio.Lock()

# ── AES ──
def encrypt_data(data: bytes) -> bytes:
    c = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return c.encrypt(pad(data, AES.block_size))

# ── PROTOBUF helpers ──
def _varint(n):
    out = []
    while True:
        b = n & 0x7F; n >>= 7
        if n: b |= 0x80
        out.append(b)
        if not n: break
    return bytes(out)

def _field(fn, v):
    if isinstance(v, bool):  return _varint((fn<<3)|0) + _varint(int(v))
    if isinstance(v, int):   return _varint((fn<<3)|0) + _varint(v)
    if isinstance(v, bytes): return _varint((fn<<3)|2) + _varint(len(v)) + v
    if isinstance(v, str):
        b = v.encode()
        return _varint((fn<<3)|2) + _varint(len(b)) + b
    raise TypeError(f"unsupported {type(v)}")

def assemble_proto(fields: dict) -> bytes:
    return b''.join(_field(int(k), v) for k, v in fields.items())

def _read_varint(data, pos):
    result = 0; shift = 0
    while pos < len(data):
        bv = data[pos]; pos += 1
        result |= (bv & 0x7F) << shift
        if not (bv & 0x80): break
        shift += 7
    return result, pos

def _try_parse_proto(raw: bytes):
    if not raw: return None
    out = {}; pos = 0; seen = 0
    try:
        while pos < len(raw):
            tag, pos = _read_varint(raw, pos)
            if tag == 0: return None
            fn, wt = tag >> 3, tag & 7
            if fn == 0 or fn > 536870911: return None
            if wt == 0:
                v, pos = _read_varint(raw, pos)
                out[fn] = v
            elif wt == 2:
                ln, pos = _read_varint(raw, pos)
                if pos + ln > len(raw): return None
                val = raw[pos:pos+ln]; pos += ln
                n = _try_parse_proto(val)
                if n and len(n) >= 1:
                    out[fn] = n
                else:
                    try:    out[fn] = val.decode('utf-8')
                    except: out[fn] = val.hex()
            elif wt == 5:
                if pos+4 > len(raw): return None
                out[fn] = raw[pos:pos+4].hex(); pos += 4
            elif wt == 1:
                if pos+8 > len(raw): return None
                out[fn] = raw[pos:pos+8].hex(); pos += 8
            else: return None
            seen += 1
        return out if seen else None
    except: return None

# ── BODY BUILDERS ──
def build_payload(event_key: str) -> bytes:
    """Build encrypted payload for a given event."""
    fields = EVENTS[event_key]["payload"]
    return encrypt_data(assemble_proto(fields))

# ── RESPONSE PARSER ──
def parse_gacha_response(data: bytes) -> dict:
    if data and data[:2] == b'\x1f\x8b':
        try: data = _gzip.decompress(data)
        except: pass

    parsed = _try_parse_proto(data) or {}
    items = []

    inner = parsed.get(1)
    if isinstance(inner, dict):
        raw = inner.get(2, "")
        if isinstance(raw, str):
            m = re.match(r'\s*(\d+)\s*[→\-–>]+\s*(.+?)\s*$', raw)
            if m:
                iid = int(m.group(1))
                iname = m.group(2).strip()
                items.append({"id": iid, "name": iname})

    if not items:
        for mm in re.finditer(r'\b(\d{9})\b', str(parsed)):
            iid = int(mm.group(1))
            if not any(it['id'] == iid for it in items):
                items.append({"id": iid, "name": None})

    for it in items:
        default_name, rarity = classify_item(it['id'])
        if not it['name'] or it['name'].startswith("UNKNOWN"):
            it['name'] = default_name
        it['rarity'] = rarity

    return {"items": items, "raw": parsed}

# ── LOG / SAVE helpers ──
async def async_log(message: str):
    timestamp = time.strftime("[%H:%M:%S]")
    clean_msg = f"{timestamp} {message}"
    print(clean_msg)
    file_msg = re.sub(r'\033\[[0-9;]*m', '', clean_msg)
    async with LOG_LOCK:
        LOG_BUFFER.append(file_msg)

async def async_save_raw_output(data):
    try:
        async with OUTPUT_LOCK:
            OUTPUT_BUFFER.append(str(data) + "\n" + "-"*50)
    except: pass

def save_final_data():
    if LOG_BUFFER:
        print(f"\n{C_CYAN}[»] Saving Logs...{C_RESET}")
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write("\n".join(LOG_BUFFER))
    if OUTPUT_BUFFER:
        print(f"{C_CYAN}[»] Saving Raw Output...{C_RESET}")
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            f.write("\n".join(OUTPUT_BUFFER))

async def save_item_entry(rarity: str, entry: dict, file_prefix: str = "NARUTO"):
    """Save item to event-specific JSON file."""
    target = {
        "VERY_RARE": f"{file_prefix}_very_rare.json",
        "RARE":      f"{file_prefix}_rare.json",
        "NORMAL":    f"{file_prefix}_normal.json",
    }.get(rarity, f"{file_prefix}_normal.json")

    async with JSON_LOCK:
        for attempt in range(3):
            try:
                if os.path.exists(target):
                    async with aiofiles.open(target, 'r', encoding='utf-8') as f:
                        content = await f.read()
                        data = json.loads(content) if content else []
                else:
                    data = []
                data.append(entry)
                async with aiofiles.open(target, 'w', encoding='utf-8') as f:
                    await f.write(json.dumps(data, indent=4))
                return
            except Exception:
                await asyncio.sleep(0.1 * (attempt + 1))
        await async_log(f"{C_RED}[!] Failed to save {rarity} item {entry.get('item_id')}{C_RESET}")

# ── SERVER SELECT ──
SERVER_DB = {
    "BD": ("Mena", DEFAULT_URL, ["BD", "BD", "1"])
}

def select_server() -> str:
    print(f"\n{C_CYAN}[ SERVER ]{C_RESET} {C_GREEN}BD / Mena → {DEFAULT_URL}{C_RESET}")
    return DEFAULT_URL

# ── EXTERNAL JWT API ──
EXTERNAL_API_URL = "https://ff-jwt-gen-api.lovable.app//api/public/token"

async def get_token(session, uid, password, retries):
    for attempt in range(retries):
        try:
            params = {'uid': uid, 'password': password}
            async with session.get(EXTERNAL_API_URL, params=params,
                                   ssl=False,
                                   timeout=aiohttp.ClientTimeout(total=15)) as res:
                if res.status == 200:
                    data = await res.json()
                    if data.get("success"):
                        token = data.get("token")
                        if token and isinstance(token, str) and len(token) > 50:
                            return token
        except Exception:
            await asyncio.sleep(0.4)
    return None

# ── GACHA REQUEST ──
async def gacha_req(session, token, payload, url, max_retries):
    if not url.endswith("/PurchaseGacha"):
        url = f"{url}/PurchaseGacha"

    headers = {
        'User-Agent':      f"UnityPlayer/{UNITY_VER} (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        'Accept':          "*/*",
        'Accept-Encoding': "deflate, gzip",
        'Authorization':   f"Bearer {token}",
        'X-GA':            "v1 1",
        'X-Ga-Sv':         str(int(time.time())),
        'ReleaseVersion':  RELEASE_VER,
        'Content-Type':    "application/x-www-form-urlencoded",
        'X-Unity-Version': UNITY_VER,
        'Host':            LOGIN_HOST,
    }

    last_status = 0
    for _ in range(1, max_retries + 1):
        try:
            timeout = aiohttp.ClientTimeout(total=20)
            async with session.post(url, headers=headers, data=payload,
                                    ssl=False, timeout=timeout) as res:
                last_status = res.status
                if res.status == 200:
                    body = await res.read()
                    return 200, body
                elif res.status in (401, 403):
                    return res.status, None
                else:
                    await asyncio.sleep(0.2)
        except Exception:
            last_status = 999
            await asyncio.sleep(0.3)
    return last_status, None

# ─────────────────────────────────────────────
#  JWT PREFETCH CACHE
# ─────────────────────────────────────────────
jwt_cache: dict = {}
jwt_cache_lock = asyncio.Lock()

async def prefetch_token(session, acc, retries: int):
    uid = str(acc.get("uid", ""))
    pwd = acc.get("password", "")
    if not uid or not pwd:
        return
    token = await get_token(session, uid, pwd, retries)
    async with jwt_cache_lock:
        jwt_cache[uid] = token

async def prefetch_all_tokens(session, accounts: list, retries: int,
                              concurrency: int = 20):
    sem = asyncio.Semaphore(concurrency)

    async def _bounded(acc):
        async with sem:
            await prefetch_token(session, acc, retries)

    print(f"{C_CYAN}[»] Prefetching JWT tokens ({len(accounts)} accounts)...{C_RESET}")
    await asyncio.gather(*[_bounded(acc) for acc in accounts],
                         return_exceptions=True)
    warm = sum(1 for v in jwt_cache.values() if v)
    print(f"{C_GREEN}[✓] Tokens ready: {warm}/{len(accounts)}{C_RESET}\n")


# ── ACCOUNT PROCESSOR (single event) ──
async def process_account_single_event(semaphore, session, acc, idx, total,
                                       target_url, event_key, login_retry, spin_retry,
                                       shared_rare_hits, shared_counters,
                                       counters_lock, hits_lock):
    async with semaphore:
        uid = str(acc.get("uid", "Unknown"))
        pwd = acc.get("password", "Unknown")
        ev = EVENTS[event_key]
        payload = build_payload(event_key)

        await async_log(f"{C_GOLD}➤ [{idx+1}/{total}] UID: {C_CYAN}{uid}{C_RESET} | Event: {C_PINK}{ev['name']}{C_RESET}")

        async with jwt_cache_lock:
            token = jwt_cache.get(uid)

        if not token:
            token = await get_token(session, uid, pwd, login_retry)

        if not token:
            await async_log(f"{C_RED}   [✗] Token Failed{C_RESET}")
            return

        status_code, resp = await gacha_req(session, token, payload, target_url, spin_retry)

        if status_code == 200 and resp:
            try:
                parsed = parse_gacha_response(resp)
                await async_save_raw_output(parsed)
                found_items = parsed.get('items', [])

                if not found_items:
                    await async_log(f"{C_GREEN}   ✓ Spin Success - No items in response{C_RESET}")
                    return

                async with counters_lock:
                    shared_counters["total_items"] += len(found_items)

                for item in found_items:
                    iid    = item['id']
                    iname  = item['name']
                    rarity = item['rarity']

                    entry = {
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "event":     ev['name'],
                        "guestUid":  uid,
                        "guestPass": pwd,
                        "item_id":   iid,
                        "item_name": iname,
                        "rarity":    rarity,
                    }
                    await save_item_entry(rarity, entry, file_prefix=ev['prefix'])

                    if rarity == "VERY_RARE":
                        async with counters_lock:
                            shared_counters["very_rare"] += 1
                        async with hits_lock:
                            shared_rare_hits.append(
                                f"[{ev['name']}] UID: {uid} | Pass: {pwd} | ★★★ VERY RARE: {iname} (ID: {iid})"
                            )
                        await async_log(
                            f"   {C_BG_MAGENTA} ★★★ VERY RARE ★★★ {C_RESET} "
                            f"{C_GOLD}{iname} {C_PINK}(ID: {iid}){C_RESET}"
                        )
                    elif rarity == "RARE":
                        async with counters_lock:
                            shared_counters["rare"] += 1
                        async with hits_lock:
                            shared_rare_hits.append(
                                f"[{ev['name']}] UID: {uid} | Pass: {pwd} | ⭐ RARE: {iname} (ID: {iid})"
                            )
                        await async_log(
                            f"   {C_BG_YELLOW} ⭐ RARE ⭐ {C_RESET} "
                            f"{C_GOLD}{iname} {C_PINK}(ID: {iid}){C_RESET}"
                        )
                    else:
                        async with counters_lock:
                            shared_counters["normal"] += 1
                        await async_log(
                            f"   {C_CYAN}📦 NORMAL{C_RESET} "
                            f"{C_WHITE}{iname} (ID: {iid}){C_RESET}"
                        )
            except Exception as e:
                await async_log(f"{C_RED}   [!] Parse Error: {e}{C_RESET}")
        else:
            err_msg = f"HTTP {status_code}" if status_code != 999 else "Connection Fail"
            await async_log(f"{C_RED}   [✗] {err_msg}{C_RESET}")


# ── ACCOUNT PROCESSOR (all events) ──
async def process_account_all_events(semaphore, session, acc, idx, total,
                                     target_url, login_retry, spin_retry,
                                     shared_rare_hits, shared_counters,
                                     counters_lock, hits_lock):
    async with semaphore:
        uid = str(acc.get("uid", "Unknown"))
        pwd = acc.get("password", "Unknown")

        await async_log(f"{C_GOLD}➤ [{idx+1}/{total}] UID: {C_CYAN}{uid}{C_RESET} | {C_PINK}ALL EVENTS{C_RESET}")

        async with jwt_cache_lock:
            token = jwt_cache.get(uid)

        if not token:
            token = await get_token(session, uid, pwd, login_retry)

        if not token:
            await async_log(f"{C_RED}   [✗] Token Failed{C_RESET}")
            return

        # Loop through every event sequentially per account
        for event_key, ev in EVENTS.items():
            payload = build_payload(event_key)
            status_code, resp = await gacha_req(session, token, payload, target_url, spin_retry)

            if status_code == 200 and resp:
                try:
                    parsed = parse_gacha_response(resp)
                    await async_save_raw_output(parsed)
                    found_items = parsed.get('items', [])

                    if not found_items:
                        await async_log(f"   {C_DIM}✓ {ev['name']}: no items{C_RESET}")
                        continue

                    async with counters_lock:
                        shared_counters["total_items"] += len(found_items)

                    for item in found_items:
                        iid    = item['id']
                        iname  = item['name']
                        rarity = item['rarity']

                        entry = {
                            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "event":     ev['name'],
                            "guestUid":  uid,
                            "guestPass": pwd,
                            "item_id":   iid,
                            "item_name": iname,
                            "rarity":    rarity,
                        }
                        await save_item_entry(rarity, entry, file_prefix=ev['prefix'])

                        if rarity == "VERY_RARE":
                            async with counters_lock:
                                shared_counters["very_rare"] += 1
                            async with hits_lock:
                                shared_rare_hits.append(
                                    f"[{ev['name']}] UID: {uid} | Pass: {pwd} | ★★★ VERY RARE: {iname} (ID: {iid})"
                                )
                            await async_log(
                                f"   {C_BG_MAGENTA} ★★★ VERY RARE ★★★ {C_RESET} "
                                f"{C_GOLD}{iname} {C_PINK}(ID: {iid}){C_RESET}"
                            )
                        elif rarity == "RARE":
                            async with counters_lock:
                                shared_counters["rare"] += 1
                            async with hits_lock:
                                shared_rare_hits.append(
                                    f"[{ev['name']}] UID: {uid} | Pass: {pwd} | ⭐ RARE: {iname} (ID: {iid})"
                                )
                            await async_log(
                                f"   {C_BG_YELLOW} ⭐ RARE ⭐ {C_RESET} "
                                f"{C_GOLD}{iname} {C_PINK}(ID: {iid}){C_RESET}"
                            )
                        else:
                            async with counters_lock:
                                shared_counters["normal"] += 1
                            await async_log(
                                f"   {C_CYAN}📦 NORMAL{C_RESET} "
                                f"{C_WHITE}{iname} (ID: {iid}){C_RESET}"
                            )
                except Exception as e:
                    await async_log(f"{C_RED}   [!] Parse Error: {e}{C_RESET}")
            else:
                err_msg = f"HTTP {status_code}" if status_code != 999 else "Connection Fail"
                await async_log(f"{C_RED}   [✗] {ev['name']}: {err_msg}{C_RESET}")

            # small delay between events on same account to avoid rate limits
            await asyncio.sleep(0.3)


# ── MAIN ──
async def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(CREDIT_INFO)
    print()
    open(LOG_FILE, 'w').close()

    # ── resolve accounts file ────────────────────────────────
    if len(sys.argv) > 1:
        p = sys.argv[1].strip().replace('"', '').replace("'", "")
        if not os.path.exists(p):
            print(f"{C_RED}[!] File from CLI not found: {p}{C_RESET}")
            return
        print(f"{C_GREEN}[+] Using CLI file: {p}{C_RESET}")
    elif ACCOUNTS_FILE and os.path.exists(ACCOUNTS_FILE):
        p = ACCOUNTS_FILE
        print(f"{C_GREEN}[+] Using default file: {p}{C_RESET}")
    else:
        while True:
            p = input(f"{C_YELLOW}[?] Enter path of UID file: {C_RESET}").strip()
            p = p.replace('"', '').replace("'", "")
            if os.path.exists(p): break
            print(f"{C_RED}[!] File not found.{C_RESET}")

    # ── load accounts ────────────────────────────────────────
    try:
        accounts = load_accounts(p)
        print(f"{C_GREEN}[+] Loaded {len(accounts)} Accounts{C_RESET}")
    except Exception as e:
        print(f"{C_RED}[!] Failed to load accounts: {e}{C_RESET}")
        return

    target_url = select_server()

    # ── EVENT MENU ───────────────────────────────────────────
    print(f"\n{C_CYAN}╔═══════════════════════════════════════════════════════════╗{C_RESET}")
    print(f"{C_CYAN}║{C_GOLD}              🎯  SELECT SPIN EVENT  🎯                    {C_CYAN}║{C_RESET}")
    print(f"{C_CYAN}╠═══════════════════════════════════════════════════════════╣{C_RESET}")
    print(f"{C_CYAN}║{C_YELLOW} [1]{C_WHITE} NARUTO           {C_DIM}→ {{1:33, 2:1, 3:553, 4:5, 13:2}}{C_RESET}    {C_CYAN}║{C_RESET}")
    print(f"{C_CYAN}║{C_YELLOW} [2]{C_WHITE} NARUTO SKYWIN    {C_DIM}→ {{1:11, 2:1, 3:553, 4:5, 13:2}}{C_RESET}    {C_CYAN}║{C_RESET}")
    print(f"{C_CYAN}║{C_YELLOW} [3]{C_WHITE} NARUTO FIST      {C_DIM}→ {{1:29, 2:1, 3:553, 4:3, 13:2}}{C_RESET}    {C_CYAN}║{C_RESET}")
    print(f"{C_CYAN}║{C_YELLOW} [4]{C_WHITE} SASUKE BUNDLE    {C_DIM}→ {{1:91, 2:1, 3:554, 4:5, 13:2}}{C_RESET}    {C_CYAN}║{C_RESET}")
    print(f"{C_CYAN}║{C_BG_MAGENTA} [5] 🔥 SPIN ALL EVENTS (1→2→3→4)                        {C_CYAN}║{C_RESET}")
    print(f"{C_CYAN}║{C_YELLOW} [6]{C_WHITE} CUSTOM HEX PAYLOAD                                    {C_CYAN}║{C_RESET}")
    print(f"{C_CYAN}╚═══════════════════════════════════════════════════════════╝{C_RESET}")

    event_choice = input(f"\n{C_CYAN}[?] Enter Choice (default 1): {C_RESET}").strip() or "1"

    # map choice → event key (or special modes)
    spin_all = False
    custom_hex = False
    event_key = None
    custom_payload = None

    if event_choice == "1":
        event_key = "naruto"
    elif event_choice == "2":
        event_key = "skywin"
    elif event_choice == "3":
        event_key = "fist"
    elif event_choice == "4":
        event_key = "sasuke"
    elif event_choice == "5":
        spin_all = True
    elif event_choice == "6":
        custom_hex = True
        raw_hex = input(f"{C_CYAN}[?] Enter Hex Payload: {C_RESET}").strip()
        try:
            custom_payload = bytes.fromhex(raw_hex.replace(" ", ""))
            print(f"{C_GREEN}[✓] Custom payload loaded ({len(custom_payload)} bytes){C_RESET}")
        except Exception as e:
            print(f"{C_RED}[!] Invalid hex: {e}{C_RESET}")
            return
    else:
        print(f"{C_RED}[!] Invalid choice{C_RESET}")
        return

    # ── show selected mode ──
    if spin_all:
        print(f"\n{C_BG_MAGENTA}[✓] MODE: SPIN ALL EVENTS (NARUTO → SKYWIN → FIST → SASUKE){C_RESET}")
        payload = None
    elif custom_hex:
        print(f"\n{C_YELLOW}[✓] MODE: CUSTOM HEX PAYLOAD{C_RESET}")
        payload = custom_payload
    else:
        ev = EVENTS[event_key]
        print(f"\n{C_GREEN}[✓] MODE: {ev['name']}  →  payload {ev['payload']}{C_RESET}")
        payload = build_payload(event_key)

    try:
        login_retry = int(input(f"{C_CYAN}[?] Login Retry (Default 3): {C_RESET}") or "3")
        spin_retry  = 3
        start_from  = int(input(f"{C_CYAN}[?] Start from Account (Default 1): {C_RESET}") or "1") - 1
        if start_from < 0: start_from = 0
        concurrency = int(input(f"{C_CYAN}[?] Concurrency (default 5): {C_RESET}") or "5")
        if concurrency < 1: concurrency = 1
        batch_size  = int(input(f"{C_CYAN}[?] Batch Size — Gen N then Spin (Default 50): {C_RESET}") or "50")
        if batch_size < 1: batch_size = 50
    except:
        login_retry = 3
        spin_retry  = 3
        start_from  = 0
        concurrency = 5
        batch_size  = 50

    if start_from >= len(accounts):
        start_from = 0

    print(f"\n{C_GREEN}[*] Starting from Account {start_from + 1}...{C_RESET}")
    print(f"{C_GREEN}[*] Concurrency : {concurrency}{C_RESET}")
    print(f"{C_GREEN}[*] Batch Size  : {batch_size} (gen → spin per batch){C_RESET}\n")

    shared_rare_hits = []
    shared_counters  = {"very_rare": 0, "rare": 0, "normal": 0, "total_items": 0}
    counters_lock    = asyncio.Lock()
    hits_lock        = asyncio.Lock()

    semaphore = asyncio.Semaphore(concurrency)
    accounts_to_process = accounts[start_from:]
    total_accounts = len(accounts_to_process)

    batches = [
        accounts_to_process[i : i + batch_size]
        for i in range(0, total_accounts, batch_size)
    ]
    total_batches = len(batches)

    async with aiohttp.ClientSession() as session:
        for batch_idx, batch in enumerate(batches):
            batch_start_abs = start_from + batch_idx * batch_size
            print(
                f"{C_PINK}[BATCH {batch_idx + 1}/{total_batches}] "
                f"Accounts {batch_start_abs + 1}–{batch_start_abs + len(batch)}"
                f" of {len(accounts)}{C_RESET}"
            )

            # ── step 1: prefetch JWT tokens for this batch ──
            await prefetch_all_tokens(
                session, batch,
                retries=login_retry,
                concurrency=min(concurrency * 4, 40),
            )

            # ── step 2: spin this batch concurrently ──
            if spin_all:
                tasks = [
                    asyncio.create_task(
                        process_account_all_events(
                            semaphore, session, acc,
                            batch_start_abs + i, len(accounts),
                            target_url, login_retry, spin_retry,
                            shared_rare_hits, shared_counters,
                            counters_lock, hits_lock,
                        )
                    )
                    for i, acc in enumerate(batch)
                ]
            else:
                tasks = [
                    asyncio.create_task(
                        process_account_single_event(
                            semaphore, session, acc,
                            batch_start_abs + i, len(accounts),
                            target_url,
                            event_key if not custom_hex else "__custom__",
                            login_retry, spin_retry,
                            shared_rare_hits, shared_counters,
                            counters_lock, hits_lock,
                        )
                    )
                    for i, acc in enumerate(batch)
                ]
            # For custom hex, we need a different approach — use a wrapper
            if custom_hex:
                # Cancel the pre-made tasks and create custom ones
                for t in tasks:
                    t.cancel()
                tasks = [
                    asyncio.create_task(
                        _process_custom(
                            semaphore, session, acc,
                            batch_start_abs + i, len(accounts),
                            target_url, payload, login_retry, spin_retry,
                            shared_rare_hits, shared_counters,
                            counters_lock, hits_lock,
                        )
                    )
                    for i, acc in enumerate(batch)
                ]

            await asyncio.gather(*tasks, return_exceptions=True)

            print(
                f"{C_GREEN}[✓] Batch {batch_idx + 1} done — "
                f"VR:{shared_counters['very_rare']} "
                f"R:{shared_counters['rare']} "
                f"N:{shared_counters['normal']}{C_RESET}\n"
            )

    # ── FINAL REPORT ──
    print(f"\n{C_CYAN}=========================================={C_RESET}")
    print(f"{C_WHITE}      NARUTO MULTI-EVENT REPORT        {C_RESET}")
    print(f"{C_CYAN}=========================================={C_RESET}")
    print(f"{C_BG_MAGENTA} ★★★ VERY RARE: {shared_counters['very_rare']}{C_RESET}")
    print(f"{C_BG_YELLOW} ⭐ RARE:        {shared_counters['rare']}{C_RESET}")
    print(f"{C_CYAN} 📦 NORMAL:      {shared_counters['normal']}{C_RESET}")
    print(f"{C_GREEN} Total Items:    {shared_counters['total_items']}{C_RESET}")
    print(f"{C_YELLOW} Accounts:       {total_accounts}{C_RESET}")
    if spin_all:
        print(f"{C_BG_MAGENTA} Events:        ALL (4 events per account){C_RESET}")
    elif custom_hex:
        print(f"{C_YELLOW} Events:        CUSTOM PAYLOAD{C_RESET}")
    else:
        print(f"{C_GREEN} Event:         {EVENTS[event_key]['name']}{C_RESET}")
    print(f"{C_CYAN}=========================================={C_RESET}")

    with open(SUMMARY_FILE, "w", encoding="utf-8") as f:
        f.write("=== FREE FIRE NARUTO MULTI-EVENT RESULTS ===\n")
        f.write("Credit: KAWSAR | x64   |   Telegram: @kawsar449x\n\n")
        f.write(f"VERY RARE : {shared_counters['very_rare']}\n")
        f.write(f"RARE      : {shared_counters['rare']}\n")
        f.write(f"NORMAL    : {shared_counters['normal']}\n")
        f.write(f"Total     : {shared_counters['total_items']}\n\n")
        f.write("=== HITS ===\n")
        if shared_rare_hits:
            for hit in shared_rare_hits:
                print(f"{C_BG_GREEN}>> {hit}{C_RESET}")
                f.write(hit + "\n")
        else:
            print(f"{C_WHITE}No rare items found.{C_RESET}")
            f.write("No rare items found.\n")

    print(f"\n{C_YELLOW}📁 Files Generated:{C_RESET}")
    print(f"   • NARUTO_very_rare.json     — NARUTO very rare items")
    print(f"   • SKYWIN_very_rare.json     — SKYWIN very rare items")
    print(f"   • FIST_very_rare.json       — FIST very rare items")
    print(f"   • SASUKE_very_rare.json     — SASUKE very rare items")
    print(f"   • *_rare.json / *_normal.json — per-event files")
    print(f"   • {SUMMARY_FILE}     — Summary report")
    print(f"   • {LOG_FILE}         — Terminal logs")
    print(f"   • {OUTPUT_FILE}      — Raw responses")

    print(f"\n{C_PINK}═══════════════════════════════════════════════════════════{C_RESET}")
    print(f"{C_GOLD}  Made with ❤  by  KAWSAR | x64   ·   Tg: @kawsar449x{C_RESET}")
    print(f"{C_PINK}═══════════════════════════════════════════════════════════{C_RESET}\n")


# ── CUSTOM PAYLOAD PROCESSOR ──
async def _process_custom(semaphore, session, acc, idx, total,
                          target_url, payload, login_retry, spin_retry,
                          shared_rare_hits, shared_counters,
                          counters_lock, hits_lock):
    async with semaphore:
        uid = str(acc.get("uid", "Unknown"))
        pwd = acc.get("password", "Unknown")

        await async_log(f"{C_GOLD}➤ [{idx+1}/{total}] UID: {C_CYAN}{uid}{C_RESET} | {C_YELLOW}CUSTOM{C_RESET}")

        async with jwt_cache_lock:
            token = jwt_cache.get(uid)

        if not token:
            token = await get_token(session, uid, pwd, login_retry)

        if not token:
            await async_log(f"{C_RED}   [✗] Token Failed{C_RESET}")
            return

        status_code, resp = await gacha_req(session, token, payload, target_url, spin_retry)

        if status_code == 200 and resp:
            try:
                parsed = parse_gacha_response(resp)
                await async_save_raw_output(parsed)
                found_items = parsed.get('items', [])

                if not found_items:
                    await async_log(f"{C_GREEN}   ✓ Spin Success - No items{C_RESET}")
                    return

                async with counters_lock:
                    shared_counters["total_items"] += len(found_items)

                for item in found_items:
                    iid    = item['id']
                    iname  = item['name']
                    rarity = item['rarity']

                    entry = {
                        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "event":     "CUSTOM",
                        "guestUid":  uid,
                        "guestPass": pwd,
                        "item_id":   iid,
                        "item_name": iname,
                        "rarity":    rarity,
                    }
                    await save_item_entry(rarity, entry, file_prefix="CUSTOM")

                    if rarity == "VERY_RARE":
                        async with counters_lock:
                            shared_counters["very_rare"] += 1
                        async with hits_lock:
                            shared_rare_hits.append(
                                f"[CUSTOM] UID: {uid} | Pass: {pwd} | ★★★ VERY RARE: {iname} (ID: {iid})"
                            )
                        await async_log(f"   {C_BG_MAGENTA} ★★★ VERY RARE ★★★ {C_RESET} {C_GOLD}{iname} {C_PINK}(ID: {iid}){C_RESET}")
                    elif rarity == "RARE":
                        async with counters_lock:
                            shared_counters["rare"] += 1
                        async with hits_lock:
                            shared_rare_hits.append(
                                f"[CUSTOM] UID: {uid} | Pass: {pwd} | ⭐ RARE: {iname} (ID: {iid})"
                            )
                        await async_log(f"   {C_BG_YELLOW} ⭐ RARE ⭐ {C_RESET} {C_GOLD}{iname} {C_PINK}(ID: {iid}){C_RESET}")
                    else:
                        async with counters_lock:
                            shared_counters["normal"] += 1
                        await async_log(f"   {C_CYAN}📦 NORMAL{C_RESET} {C_WHITE}{iname} (ID: {iid}){C_RESET}")
            except Exception as e:
                await async_log(f"{C_RED}   [!] Parse Error: {e}{C_RESET}")
        else:
            err_msg = f"HTTP {status_code}" if status_code != 999 else "Connection Fail"
            await async_log(f"{C_RED}   [✗] {err_msg}{C_RESET}")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\n\n{C_RED}[!] Stopped by User.{C_RESET}")
    finally:
        save_final_data()